﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ApkTool
{

    /// <summary>
    /// 工具函数类，定义一些通用的功能逻辑
    /// </summary>
    public class Tools
    {

//[
//    {
//        "id": "28674",
//        "company": "奇虎360安卓推广渠道2",
//        "name": "360手机开放平台",
//        "apkname": "com.joym.datoufighter.sj360",
//        "channel_id": "0000843",
//        "app_id": "267",
//        "ct": "80011046"
//    }
//]

        /// <summary>
        /// 解析JsonStr中的所有keysName = "channel_param" 属性到Dictionary中存储
        /// </summary>
        public static Dictionary<String, String> getParams(string JsonStr)
        {
            Dictionary<String, String> channel_param = new Dictionary<string, string>();

            // 获取渠道所有参数
            if(JsonStr.Contains("{") && JsonStr.Contains("}"))
            {
                int S1 = JsonStr.IndexOf("{") + 1, S2 = JsonStr.LastIndexOf("}");
                String innerStr = JsonStr.Substring(S1, S2 - S1);

                String[] A = innerStr.Split(',');
                foreach (String param in A)
                {
                    if (!param.Trim().Equals("") && param.Contains(":"))
                    {
                        String[] V = split(param, ":");
                        channel_param.Add(V[0].Trim('"'), Format(V[1].Trim('"')).Trim());   // 获取渠道配置参数信息
                    }
                }
            }

            return channel_param;
        }


        /// <summary>
        /// 将data按seprator分割为两个子串
        /// </summary>
        public static string[] split(string data, string seprator)
        {
            if (data.Contains(seprator))
            {
                int S = data.IndexOf(seprator), E = S + seprator.Length;
                string[] A = new string[2];
                A[0] = data.Substring(0, S).Trim();
                A[1] = data.Substring(E).Trim();

                return A;
            }
            else return new string[] { data };
        }


        /// <summary>
        /// 将@"\u5357\u7f8e\u89e3\u653e\u8005\u676f"; 转化为字符串形式
        /// </summary>
        public static String Format(String str)
        {
            if (str.Contains(@"\u")) str = ConvertUnicodeStringToChinese(str);

            // 对url进行校验 "https:\\/\\/ysdktest.qq.com"
            if (str.Contains(@"\") && (str.StartsWith("https:") || str.StartsWith("http:")))
                str = str.Replace("\\", "");

            if (str.Contains("\\")) str = str.Replace("\\", "");    // 剔除串中的符号"\"

            return str;
        }

        /// <summary>
        /// 将unicode转换为中文
        /// </summary>
        /// <param name="unicodeString">unicode字符串</param>
        /// <returns>unicode解码的字符串</returns>
        public static string ConvertUnicodeStringToChinese(string unicodeString)
        {
            if (string.IsNullOrEmpty(unicodeString))
                return string.Empty;

            string outStr = unicodeString;

            Regex re = new Regex("\\\\u[0123456789abcdef]{4}", RegexOptions.IgnoreCase);
            MatchCollection mc = re.Matches(unicodeString);
            foreach (Match ma in mc)
            {
                outStr = outStr.Replace(ma.Value, ConverUnicodeStringToChar(ma.Value).ToString());
            }
            return outStr;
        }

        private static char ConverUnicodeStringToChar(string str)
        {
            char outStr = Char.MinValue;
            outStr = (char)int.Parse(str.Remove(0, 2), System.Globalization.NumberStyles.HexNumber);
            return outStr;
        }



        /// <summary>
        /// 将一个字符串按分割符，分割为两个串
        /// </summary>
        public static String[] SplitTwo(String str, String seprator, bool trim = true)
        {
            String[] tmp = null;
            if (str.Contains(seprator))
            {
                int index = str.IndexOf(seprator);

                String key = str.Substring(0, index);
                String value = str.Substring(index + seprator.Length);

                if (trim) key = key.Trim();
                if (trim) value = value.Trim();

                tmp = new String[] { key, value };
            }
            else tmp = new String[] { str };

            return tmp;
        }
    }
}
