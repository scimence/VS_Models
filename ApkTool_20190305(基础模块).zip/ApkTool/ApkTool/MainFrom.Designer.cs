﻿namespace ApkTool
{
    partial class MainFrom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_sign = new System.Windows.Forms.ComboBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.Modify = new System.Windows.Forms.Button();
            this.dirDest = new System.Windows.Forms.TextBox();
            this.checkBox_SignAll = new System.Windows.Forms.CheckBox();
            this.checkBox_AddLog = new System.Windows.Forms.CheckBox();
            this.checkBox_modifyAdId = new System.Windows.Forms.CheckBox();
            this.linkLabel_modifyAdId = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 36;
            this.label1.Text = "游戏包：";
            // 
            // comboBox_sign
            // 
            this.comboBox_sign.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_sign.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_sign.FormattingEnabled = true;
            this.comboBox_sign.Location = new System.Drawing.Point(398, 19);
            this.comboBox_sign.Name = "comboBox_sign";
            this.comboBox_sign.Size = new System.Drawing.Size(73, 20);
            this.comboBox_sign.TabIndex = 35;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox1.Location = new System.Drawing.Point(13, 65);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(551, 307);
            this.richTextBox1.TabIndex = 34;
            this.richTextBox1.Text = "";
            // 
            // Modify
            // 
            this.Modify.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Modify.Location = new System.Drawing.Point(489, 17);
            this.Modify.Name = "Modify";
            this.Modify.Size = new System.Drawing.Size(75, 21);
            this.Modify.TabIndex = 33;
            this.Modify.Text = "修改";
            this.Modify.UseVisualStyleBackColor = true;
            this.Modify.Click += new System.EventHandler(this.Modify_Click);
            // 
            // dirDest
            // 
            this.dirDest.AllowDrop = true;
            this.dirDest.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dirDest.Location = new System.Drawing.Point(71, 18);
            this.dirDest.Name = "dirDest";
            this.dirDest.Size = new System.Drawing.Size(400, 21);
            this.dirDest.TabIndex = 32;
            this.dirDest.DragDrop += new System.Windows.Forms.DragEventHandler(this.dirDest_DragDrop);
            this.dirDest.DragEnter += new System.Windows.Forms.DragEventHandler(this.dirDest_DragEnter);
            // 
            // checkBox_SignAll
            // 
            this.checkBox_SignAll.AutoSize = true;
            this.checkBox_SignAll.Location = new System.Drawing.Point(16, 47);
            this.checkBox_SignAll.Name = "checkBox_SignAll";
            this.checkBox_SignAll.Size = new System.Drawing.Size(96, 16);
            this.checkBox_SignAll.TabIndex = 37;
            this.checkBox_SignAll.Text = "生成所有签名";
            this.checkBox_SignAll.UseVisualStyleBackColor = true;
            // 
            // checkBox_AddLog
            // 
            this.checkBox_AddLog.AutoSize = true;
            this.checkBox_AddLog.Location = new System.Drawing.Point(132, 47);
            this.checkBox_AddLog.Name = "checkBox_AddLog";
            this.checkBox_AddLog.Size = new System.Drawing.Size(114, 16);
            this.checkBox_AddLog.TabIndex = 38;
            this.checkBox_AddLog.Text = "添加log输出逻辑";
            this.checkBox_AddLog.UseVisualStyleBackColor = true;
            // 
            // checkBox_modifyAdId
            // 
            this.checkBox_modifyAdId.AutoSize = true;
            this.checkBox_modifyAdId.Location = new System.Drawing.Point(265, 47);
            this.checkBox_modifyAdId.Name = "checkBox_modifyAdId";
            this.checkBox_modifyAdId.Size = new System.Drawing.Size(15, 14);
            this.checkBox_modifyAdId.TabIndex = 39;
            this.checkBox_modifyAdId.UseVisualStyleBackColor = true;
            // 
            // linkLabel_modifyAdId
            // 
            this.linkLabel_modifyAdId.AutoSize = true;
            this.linkLabel_modifyAdId.Location = new System.Drawing.Point(285, 48);
            this.linkLabel_modifyAdId.Name = "linkLabel_modifyAdId";
            this.linkLabel_modifyAdId.Size = new System.Drawing.Size(65, 12);
            this.linkLabel_modifyAdId.TabIndex = 40;
            this.linkLabel_modifyAdId.TabStop = true;
            this.linkLabel_modifyAdId.Text = "修改广告id";
            // 
            // MainFrom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(576, 388);
            this.Controls.Add(this.linkLabel_modifyAdId);
            this.Controls.Add(this.checkBox_modifyAdId);
            this.Controls.Add(this.checkBox_AddLog);
            this.Controls.Add(this.checkBox_SignAll);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox_sign);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.Modify);
            this.Controls.Add(this.dirDest);
            this.Name = "MainFrom";
            this.Text = "MainFrom";
            this.Load += new System.EventHandler(this.MainFrom_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_sign;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button Modify;
        private System.Windows.Forms.TextBox dirDest;
        private System.Windows.Forms.CheckBox checkBox_SignAll;
        private System.Windows.Forms.CheckBox checkBox_AddLog;
        private System.Windows.Forms.CheckBox checkBox_modifyAdId;
        private System.Windows.Forms.LinkLabel linkLabel_modifyAdId;
    }
}